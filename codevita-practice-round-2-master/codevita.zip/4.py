for _ in range(int(input())):
    a=input()
    if len(set(a))==len(a):
        print("No")
    else:
        print("Yes")
